const ozadje_slika = new Image();
ozadje_slika.src= "img/gozd2.jpeg";